# Katy-Eulera-Unity3D
App to show how Euler Angles works, in any convention, we can rotate/zoom/ set angle etc, manual in PDF
